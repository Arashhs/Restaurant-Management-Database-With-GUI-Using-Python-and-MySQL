create definer = root@localhost trigger del_customerLog
    before delete
    on customer
    for each row
BEGIN
    INSERT INTO customer_log VALUES(Now(), 'customer', 'insert', OLD.CID, OLD.FName, OLD.LName, OLD.NID, OLD.cphone, OLD.age);
END;

