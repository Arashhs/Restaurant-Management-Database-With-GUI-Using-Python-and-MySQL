create definer = root@localhost trigger update_order_menuLog
    before update
    on order_menu
    for each row
BEGIN
    INSERT INTO order_menu_log VALUES(Now(), 'order_menu', 'update', OLD.orderID, OLD.foodName, OLD.price, OLD.unit);
END;

