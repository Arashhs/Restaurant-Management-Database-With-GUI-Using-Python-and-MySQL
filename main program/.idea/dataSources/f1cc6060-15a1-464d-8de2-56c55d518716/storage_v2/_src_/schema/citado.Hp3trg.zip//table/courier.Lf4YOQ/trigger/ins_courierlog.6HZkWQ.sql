create definer = root@localhost trigger ins_courierLog
    after insert
    on courier
    for each row
BEGIN
    INSERT INTO courier_log VALUES(Now(), 'courier', 'insert', NEW.CNID, NEW.CID, NEW.CFName, NEW.CLName, NEW.cphone);
END;

