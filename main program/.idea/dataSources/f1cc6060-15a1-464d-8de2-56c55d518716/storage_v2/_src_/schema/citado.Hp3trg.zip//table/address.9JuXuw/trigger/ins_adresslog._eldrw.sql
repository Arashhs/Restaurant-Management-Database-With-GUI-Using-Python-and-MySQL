create definer = root@localhost trigger ins_adressLog
    after insert
    on address
    for each row
BEGIN
    INSERT INTO address_log VALUES(Now(), 'address', 'insert', NEW.AID, NEW.CID, NEW.name, NEW.address, NEW.fphone);
END;

