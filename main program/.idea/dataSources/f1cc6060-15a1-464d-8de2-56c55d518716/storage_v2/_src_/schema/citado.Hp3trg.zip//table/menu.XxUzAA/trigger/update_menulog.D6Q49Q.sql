create definer = root@localhost trigger update_menuLog
    before update
    on menu
    for each row
BEGIN
    INSERT INTO menu_log VALUES(Now(), 'menu', 'insert', OLD.foodName, OLD.price, OLD.start, OLD.end);
END;

