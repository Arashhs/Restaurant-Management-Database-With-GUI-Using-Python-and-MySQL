create definer = root@localhost trigger update_shoporder_itemsLog
    before update
    on shoporder_items
    for each row
BEGIN
    INSERT INTO shoporder_items_log VALUES(Now(), 'shoporder_items', 'update', OLD.orderID, OLD.SID, OLD.IID, OLD.Iprice, OLD.unit);
END;

