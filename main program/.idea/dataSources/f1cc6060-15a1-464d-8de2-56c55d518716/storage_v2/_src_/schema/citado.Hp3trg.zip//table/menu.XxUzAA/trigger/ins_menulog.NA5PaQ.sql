create definer = root@localhost trigger ins_menuLog
    after insert
    on menu
    for each row
BEGIN
    INSERT INTO menu_log VALUES(Now(), 'menu', 'insert', NEW.foodName, NEW.price, new.start, new.end);
END;

