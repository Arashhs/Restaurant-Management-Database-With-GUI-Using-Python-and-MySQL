create definer = root@localhost trigger del_shopItemLog
    before delete
    on shopitem
    for each row
BEGIN
    INSERT INTO shopItem_log VALUES(Now(), 'shopItem', 'delete', OLD.SID, OLD.IID, OLD.IName, OLD.Iprice, OLD.start, OLD.end);
END;

