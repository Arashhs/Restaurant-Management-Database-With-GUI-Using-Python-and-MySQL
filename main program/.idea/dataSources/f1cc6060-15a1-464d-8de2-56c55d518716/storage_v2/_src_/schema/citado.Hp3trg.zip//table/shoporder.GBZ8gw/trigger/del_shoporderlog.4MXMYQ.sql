create definer = root@localhost trigger del_shopOrderLog
    before delete
    on shoporder
    for each row
BEGIN
    INSERT INTO shopOrder_log VALUES(Now(), 'shopOrder', 'delete', OLD.orderID, OLD.SID, OLD.orderDate);
END;

