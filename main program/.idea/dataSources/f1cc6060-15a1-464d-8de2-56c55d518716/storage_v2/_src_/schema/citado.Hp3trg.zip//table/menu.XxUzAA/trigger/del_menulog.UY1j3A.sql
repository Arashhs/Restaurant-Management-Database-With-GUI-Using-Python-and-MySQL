create definer = root@localhost trigger del_menuLog
    before delete
    on menu
    for each row
BEGIN
    INSERT INTO menu_log VALUES(Now(), 'menu', 'insert', OLD.foodName, OLD.price, OLD.start, OLD.end);
END;

