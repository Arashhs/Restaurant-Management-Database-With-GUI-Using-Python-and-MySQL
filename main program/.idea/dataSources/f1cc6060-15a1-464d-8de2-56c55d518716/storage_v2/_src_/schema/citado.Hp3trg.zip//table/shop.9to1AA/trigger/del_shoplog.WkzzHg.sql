create definer = root@localhost trigger del_shopLog
    before delete
    on shop
    for each row
BEGIN
    INSERT INTO shop_log VALUES(Now(), 'orders', 'delete', OLD.SID, OLD.SName, OLD.status);
END;

