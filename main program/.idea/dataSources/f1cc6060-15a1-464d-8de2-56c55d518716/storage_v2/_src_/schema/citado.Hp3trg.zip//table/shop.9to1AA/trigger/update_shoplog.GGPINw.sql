create definer = root@localhost trigger update_shopLog
    before update
    on shop
    for each row
BEGIN
    INSERT INTO shop_log VALUES(Now(), 'orders', 'update', OLD.SID, OLD.SName, OLD.status);
END;

