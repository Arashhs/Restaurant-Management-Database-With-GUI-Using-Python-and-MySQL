create definer = root@localhost trigger ins_shopOrderLog
    after insert
    on shoporder
    for each row
BEGIN
    INSERT INTO shopOrder_log VALUES(Now(), 'shopOrder', 'insert', NEW.orderID, new.SID, new.orderDate);
END;

