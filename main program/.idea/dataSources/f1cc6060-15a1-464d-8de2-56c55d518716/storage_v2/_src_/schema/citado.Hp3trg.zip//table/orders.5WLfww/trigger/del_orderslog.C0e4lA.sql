create definer = root@localhost trigger del_ordersLog
    before delete
    on orders
    for each row
BEGIN
    INSERT INTO orders_log VALUES(Now(), 'orders', 'update', OLD.orderID, OLD.orderDate, OLD.customerID, OLD.AID, OLD.courierID);
END;

